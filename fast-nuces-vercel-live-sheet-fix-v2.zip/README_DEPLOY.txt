FAST NUCES live Google Sheet fix for Vercel

Why this version is different:
- index.html no longer fetches Google Sheets directly from the browser.
- It calls /api/timetable every 5 minutes.
- /api/timetable.js runs on Vercel's server, fetches Google Sheets there, parses it, then sends clean JSON to the page.
- This avoids the common Google Sheets CORS problem that makes static HTML fall back to hardcoded TT data.

Deploy steps:
1. Copy index.html into the root of your GitHub repo.
2. Copy the api folder into the root of your GitHub repo, so the file path is exactly:
   api/timetable.js
3. Commit and push to GitHub.
4. Redeploy on Vercel.
5. Open your deployed site. The header should show:
   SHEET: LIVE VIA API · ... CLASSES

Debug URLs after deployment:
- https://YOUR-VERCEL-DOMAIN.vercel.app/api/timetable
  Should return JSON with ok:true and count greater than 0.

- https://YOUR-VERCEL-DOMAIN.vercel.app/api/timetable?raw=1
  Shows the first 20 rows from each Google Sheet tab so you can confirm Vercel can read the sheet.

If the page still says API ERROR:
- Make sure api/timetable.js exists in the deployed repo, not only index.html.
- Make sure the Google Sheet is shared as Anyone with the link can view.
- Visit /api/timetable?raw=1 and copy the JSON/error.
